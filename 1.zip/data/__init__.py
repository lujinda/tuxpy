#!/usr/bin/env python
#coding:utf8
# Author          : tuxpy
# Email           : q8886888@qq.com
# Last modified   : 2014-11-30 23:53:01
# Filename        : data/__init__.py
# Description     : 
from db import db
