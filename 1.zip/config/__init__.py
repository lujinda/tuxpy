#!/usr/bin/env python
#coding:utf8
# Author          : tuxpy
# Email           : q8886888@qq.com
# Last modified   : 2015-01-05 20:32:25
# Filename        : config/__init__.py
# Description     : 
from .config import  cfg_file, db_config

