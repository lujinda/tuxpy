#!/usr/bin/env python
#coding:utf8
# Author          : tuxpy
# Email           : q8886888@qq.com
# Last modified   : 2014-12-07 15:11:02
# Filename        : config/__init__.py
# Description     : 
from .config import  cfg_file, db_config
